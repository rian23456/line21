# selfbotkc

# Bahan yang dibutuhkan
- Termux
- Termux api
- next keyboard

# Cara pasang:
buka termux
ketik
- pkg update && pkg upgrade
- pkg install python
- pkg install git
- pkg install nano
- pkg install python3-pip 
- pip3 install rsa 
- pip3 install thrift==0.11.0 
- pip3 install requests 
- pip3 install bs4 
- pip3 install gtts 
- pip3 install beautifulsoup 
- pip3 install googletrans 
- pip3 install pafy 
- pip3 install humanfriendly 
- pip3 install goslate 
- pip3 install wikipedia 
- pip3 install youtube_dl 
- pip3 install tweepy
- python -m pip install -r requirements.txt
- git clone https://github.com/mashirourahara/selfbotkc.git
- cd selfbotkc
- python3 sh.py

setelah berhasil login, buka kembali termux masukan mid di dalam file bot
Caranya
Termuk
- cd selfbotkc
- nano sh.py
- masukan authToken & mid akun line (cek video)

lalu save
alt+x
y
alt+t
Enter


Jalankan ulang bot kalian! ^_^
untuk menjalankan bot cukup
Buka termux
- cd selfbotkc
- python3 sh.py



Semoga bermanfaat!
Kurang/lebih nya mohon maaf
Jika kurang jelas bisa kontak saya di

line.me/ti/p/~mashiro.ch4n
